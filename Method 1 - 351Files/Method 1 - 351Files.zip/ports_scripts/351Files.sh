#!/bin/bash

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2019-present Shanti Gilbert (https://github.com/shantigilbert)

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
source $controlfolder/tasksetter

get_controls
CUR_TTY=/dev/tty0

GAMEDIR=/$directory/ports/351Files

cd $GAMEDIR

export SDL_AUDIODRIVER=alsa

chmod +x ./351Files

export LD_LIBRARY_PATH=$GAMEDIR:$LD_LIBRARY_PATH
         
$GPTOKEYB "351Files" -c "./351Files.gptk" &
./351Files | tee -a ./log351.txt


